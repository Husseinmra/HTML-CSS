document.addEventListener("DOMContentLoaded", () => {
  // Configuração do slider automático na página inicial
  const slides = ["slide-1", "slide-2", "slide-3"];
  let currentSlide = 0;

  // Esta função troca os slides automaticamente a cada 5 segundos
  function rotateSlides() {
    history.replaceState(null, null, " ");
    currentSlide = (currentSlide + 1) % slides.length;
    location.hash = slides[currentSlide];
  }

  const slideInterval = setInterval(rotateSlides, 5000);

  // Quando o usuário clica em um dos botões de navegação do slider,
  // pausamos a rotação automática por 10 segundos e depois retomamos
  document.querySelectorAll(".slider-nav a").forEach((nav) => {
    nav.addEventListener("click", () => {
      clearInterval(slideInterval);

      setTimeout(() => {
        const hash = location.hash.substring(1);
        currentSlide = slides.indexOf(hash);
        if (currentSlide === -1) currentSlide = 0;

        setInterval(rotateSlides, 5000);
      }, 10000);
    });
  });

  // Botão de "voltar ao topo" que aparece quando rolamos a página
  const backToTopButton = document.querySelector(".back-to-top");

  window.addEventListener("scroll", () => {
    if (window.pageYOffset > 300) {
      backToTopButton.classList.add("visible");
    } else {
      backToTopButton.classList.remove("visible");
    }
  });

  // Controles para alternar entre visualização em grade e lista de produtos
  const gridViewBtn = document.querySelector(".grid-view");
  const listViewBtn = document.querySelector(".list-view");
  const productsGrid = document.querySelector(".products-grid");

  if (gridViewBtn && listViewBtn) {
    gridViewBtn.addEventListener("click", () => {
      productsGrid.classList.remove("list-view");
      gridViewBtn.classList.add("active");
      listViewBtn.classList.remove("active");
    });

    listViewBtn.addEventListener("click", () => {
      productsGrid.classList.add("list-view");
      listViewBtn.classList.add("active");
      gridViewBtn.classList.remove("active");
    });
  }

  // Controles do carrossel de produtos em destaque
  const prevBtn = document.querySelector(".prev-btn");
  const nextBtn = document.querySelector(".next-btn");
  const carouselTrack = document.querySelector(".carousel-track");

  if (prevBtn && nextBtn && carouselTrack) {
    prevBtn.addEventListener("click", () => {
      carouselTrack.style.animationPlayState = "paused";
      const items = document.querySelectorAll(".carousel-item");
      carouselTrack.prepend(items[items.length - 1]);
    });

    nextBtn.addEventListener("click", () => {
      carouselTrack.style.animationPlayState = "paused";
      const items = document.querySelectorAll(".carousel-item");
      carouselTrack.appendChild(items[0]);
    });
  }

  // Efeito de elevação nos cards de produtos quando passamos o mouse
  const productCards = document.querySelectorAll(".product-card");

  productCards.forEach((card) => {
    card.addEventListener("mouseenter", function () {
      this.style.transform = "translateY(-10px)";
    });

    card.addEventListener("mouseleave", function () {
      this.style.transform = "translateY(0)";
    });
  });

  // Validação do formulário de contato
  const contactForm = document.querySelector(".contact-form");

  if (contactForm) {
    contactForm.addEventListener("submit", (e) => {
      e.preventDefault();

      const nameInput = document.getElementById("name");
      const emailInput = document.getElementById("email");
      const messageInput = document.getElementById("message");

      let isValid = true;

      // Verificamos se todos os campos estão preenchidos corretamente
      if (!nameInput.value.trim()) {
        isValid = false;
        nameInput.style.borderColor = "var(--danger-color)";
      } else {
        nameInput.style.borderColor = "var(--success-color)";
      }

      if (!emailInput.value.trim() || !isValidEmail(emailInput.value)) {
        isValid = false;
        emailInput.style.borderColor = "var(--danger-color)";
      } else {
        emailInput.style.borderColor = "var(--success-color)";
      }

      if (!messageInput.value.trim()) {
        isValid = false;
        messageInput.style.borderColor = "var(--danger-color)";
      } else {
        messageInput.style.borderColor = "var(--success-color)";
      }

      // Se tudo estiver ok, mostramos uma mensagem de sucesso
      if (isValid) {
        alert("Mensagem enviada com sucesso!");
        contactForm.reset();
      }
    });
  }

  // Função auxiliar para validar formato de email
  function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  // Validação do formulário de newsletter
  const newsletterForm = document.querySelector(".newsletter-form");

  if (newsletterForm) {
    newsletterForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const emailInput = this.querySelector('input[type="email"]');

      if (!emailInput.value.trim() || !isValidEmail(emailInput.value)) {
        emailInput.style.borderColor = "var(--danger-color)";
      } else {
        emailInput.style.borderColor = "var(--success-color)";
        alert("Inscrição realizada com sucesso!");
        newsletterForm.reset();
      }
    });
  }

  // Botões de adicionar ao carrinho com feedback visual
  const addToCartButtons = document.querySelectorAll(".btn-cart");

  addToCartButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const productName = this.closest(".product-card").querySelector("h3").textContent;
      alert(`${productName} adicionado ao carrinho!`);

      // Mudamos o texto e a cor do botão temporariamente para dar feedback
      this.textContent = "Adicionado ✓";
      this.style.backgroundColor = "var(--success-color)";

      // Depois de 2 segundos, voltamos o botão ao estado original
      setTimeout(() => {
        this.textContent = "Adicionar ao Carrinho";
        this.style.backgroundColor = "var(--primary-color)";
      }, 2000);
    });
  });
});
